"""
Policy engine.

Validates a proposed Terraform module selection (and its rendered HCL) against
the org-wide standards defined in `policies/standards.yaml`. Returns a list of
`PolicyViolation` entries; the graph blocks emission if any are `severity: error`.

Design notes
------------
* Rules are *data-driven*, not code, so security can change them without a
  redeploy of the agent.
* We deliberately do NOT call out to OPA / Sentinel here to keep the reference
  implementation self-contained, but the engine exposes the same contract so
  swapping in `opa eval` later is a drop-in change.
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Any

import yaml

from agent.state import ModuleSelection, PolicyViolation


_POLICY_PATH = Path(__file__).resolve().parents[1] / "policies" / "standards.yaml"


class PolicyEngine:
    def __init__(self, policy_path: Path | str | None = None) -> None:
        path = Path(policy_path) if policy_path else _POLICY_PATH
        with path.open() as f:
            self.policy: dict[str, Any] = yaml.safe_load(f)

    # ------------------------------------------------------------------ #
    # public API
    # ------------------------------------------------------------------ #

    def evaluate(
        self,
        selections: list[ModuleSelection],
        rendered_hcl: str,
        environment: str,
        tags: dict[str, str],
    ) -> list[PolicyViolation]:
        violations: list[PolicyViolation] = []
        violations += self._check_mandatory_modules(selections)
        violations += self._check_vm_skus(selections)
        violations += self._check_tags(tags)
        violations += self._check_forbidden_patterns(rendered_hcl)
        violations += self._check_env_specific(selections, environment)
        return violations

    @staticmethod
    def is_blocking(violations: list[PolicyViolation]) -> bool:
        return any(v["severity"] == "error" for v in violations)

    # ------------------------------------------------------------------ #
    # individual rule checks
    # ------------------------------------------------------------------ #

    def _check_mandatory_modules(
        self, selections: list[ModuleSelection]
    ) -> list[PolicyViolation]:
        present = {s["module_name"] for s in selections}
        out: list[PolicyViolation] = []
        for required in self.policy.get("mandatory_modules", []):
            if required not in present:
                out.append(PolicyViolation(
                    rule_id="POL-001",
                    severity="error",
                    message=f"Mandatory module '{required}' missing from plan",
                    offending_module=None,
                ))
        return out

    def _check_vm_skus(
        self, selections: list[ModuleSelection]
    ) -> list[PolicyViolation]:
        approved_general = set(self.policy["approved_vm_skus"]["general_purpose"])
        approved_gpu = set(self.policy["approved_vm_skus"]["gpu"])
        approved = approved_general | approved_gpu
        out: list[PolicyViolation] = []
        for sel in selections:
            if sel["module_name"] in {"vmss_linux", "vmss_gpu"}:
                sku = sel["inputs"].get("sku")
                if sku not in approved:
                    out.append(PolicyViolation(
                        rule_id="POL-002",
                        severity="error",
                        message=(f"VM SKU '{sku}' is not on the approved list. "
                                 f"Approved: {sorted(approved)}"),
                        offending_module=sel["module_name"],
                    ))
        return out

    def _check_tags(self, tags: dict[str, str]) -> list[PolicyViolation]:
        out: list[PolicyViolation] = []
        for required in self.policy.get("mandatory_tags", []):
            if not tags.get(required):
                out.append(PolicyViolation(
                    rule_id="POL-003",
                    severity="error",
                    message=f"Mandatory tag '{required}' is missing or empty",
                    offending_module=None,
                ))
        return out

    def _check_forbidden_patterns(self, hcl: str) -> list[PolicyViolation]:
        out: list[PolicyViolation] = []
        for pattern in self.policy.get("forbidden_hcl_patterns", []):
            if re.search(pattern, hcl):
                out.append(PolicyViolation(
                    rule_id="POL-004",
                    severity="error",
                    message=f"Generated HCL contains forbidden pattern: '{pattern}'",
                    offending_module=None,
                ))
        return out

    def _check_env_specific(
        self,
        selections: list[ModuleSelection],
        environment: str,
    ) -> list[PolicyViolation]:
        out: list[PolicyViolation] = []
        env_rules = (self.policy.get("environments") or {}).get(environment) or {}
        min_inst = env_rules.get("min_instance_count")
        if min_inst is None:
            return out
        for sel in selections:
            if sel["module_name"] not in {"vmss_linux", "vmss_gpu"}:
                continue
            count = sel["inputs"].get("instance_count", 0)
            if count < min_inst:
                out.append(PolicyViolation(
                    rule_id="POL-005",
                    severity="error",
                    message=(f"instance_count={count} is below the "
                             f"{environment} minimum of {min_inst}"),
                    offending_module=sel["module_name"],
                ))
        if env_rules.get("purge_protection_required"):
            for sel in selections:
                if sel["module_name"] != "key_vault":
                    continue
                if not sel["inputs"].get("purge_protection_enabled"):
                    out.append(PolicyViolation(
                        rule_id="POL-006",
                        severity="error",
                        message=("Key Vault purge protection must be enabled "
                                 f"in {environment}"),
                        offending_module="key_vault",
                    ))
        return out
