"""
LangGraph orchestrator.

The graph has three node types:

    plan_step      The LLM decides what to do next (tool-call or finish).
    tool_step      Execute the tool the LLM requested.
    policy_repair  Special-case loop: if the policy engine emitted blocking
                   violations, feed them back to the model so it can revise
                   the selections before retrying.

Transitions:

    START -> plan_step
    plan_step --(tool_call)--> tool_step --> plan_step
    plan_step --(final answer)--> END
    plan_step --(check_policy returned failures)--> policy_repair -> plan_step

We cap iteration at MAX_ITER to prevent runaway loops.
"""
from __future__ import annotations

import json
from typing import Any, Literal

from langgraph.graph import StateGraph, START, END

from agent.state import AgentState
from agent.llm import AzureOpenAIChat, SYSTEM_PROMPT
from agent.tool_registry import TOOLS, IMPLEMENTATIONS


MAX_ITER = 20


# ----------------------------- nodes ---------------------------------------


def _plan_step(state: AgentState, llm: AzureOpenAIChat) -> dict[str, Any]:
    """Ask the LLM what to do next."""
    history = list(state.get("messages") or [])
    if not history:
        history = [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": _initial_user_message(state)},
        ]
    msg = llm.chat(history, tools=TOOLS)
    new_msgs = history + [msg] if not state.get("messages") else [msg]
    # On the first turn we also seeded the system/user messages — they need
    # to flow into the accumulator too.
    return {
        "messages": new_msgs,
        "iteration": (state.get("iteration") or 0) + 1,
    }


def _tool_step(state: AgentState) -> dict[str, Any]:
    """Run every tool_call the assistant emitted in its last message."""
    last = state["messages"][-1]
    tool_calls = last.get("tool_calls") or []
    out_msgs: list[dict[str, Any]] = []
    for tc in tool_calls:
        name = tc["function"]["name"]
        try:
            args = json.loads(tc["function"]["arguments"] or "{}")
        except json.JSONDecodeError:
            args = {}
        impl = IMPLEMENTATIONS.get(name)
        if impl is None:
            result = {"error": f"unknown tool: {name}"}
        else:
            try:
                result = impl(args, state)
            except Exception as exc:                                # noqa: BLE001
                result = {"error": f"{type(exc).__name__}: {exc}"}
        out_msgs.append({
            "role": "tool",
            "tool_call_id": tc["id"],
            "name": name,
            "content": json.dumps(result, default=str),
        })
    return {"messages": out_msgs}


def _policy_repair(state: AgentState) -> dict[str, Any]:
    """Inject a synthetic user turn instructing the model to revise."""
    violations = state.get("policy_violations") or []
    if not violations:
        return {}
    prompt = (
        "The policy engine rejected the proposed plan with the following "
        "blocking violations:\n\n"
        + "\n".join(f"- [{v['rule_id']}] {v['message']}" for v in violations)
        + "\n\nRevise the module selections (or their inputs) so every "
          "violation is resolved, then re-run render_and_plan and check_policy."
    )
    return {"messages": [{"role": "user", "content": prompt}]}


# --------------------------- routing logic ---------------------------------


def _route_after_plan(state: AgentState) -> Literal["tool", "end"]:
    if (state.get("iteration") or 0) >= MAX_ITER:
        return "end"
    last = state["messages"][-1]
    if last.get("tool_calls"):
        return "tool"
    return "end"


def _route_after_tool(state: AgentState) -> Literal["plan", "repair"]:
    """If check_policy just failed, go through the repair node instead."""
    last_results = [m for m in state["messages"][-5:] if m["role"] == "tool"]
    for m in reversed(last_results):
        if m["name"] == "check_policy":
            payload = json.loads(m["content"])
            if not payload.get("passed"):
                return "repair"
            break
    return "plan"


# ----------------------------- builder -------------------------------------


def build_graph(llm: AzureOpenAIChat | None = None):
    llm = llm or AzureOpenAIChat()
    graph = StateGraph(AgentState)

    graph.add_node("plan", lambda s: _plan_step(s, llm))
    graph.add_node("tool", _tool_step)
    graph.add_node("repair", _policy_repair)

    graph.add_edge(START, "plan")
    graph.add_conditional_edges("plan", _route_after_plan,
                                {"tool": "tool", "end": END})
    graph.add_conditional_edges("tool", _route_after_tool,
                                {"plan": "plan", "repair": "repair"})
    graph.add_edge("repair", "plan")

    return graph.compile()


# ---------------------------- helpers --------------------------------------


def _initial_user_message(state: AgentState) -> str:
    return (
        f"Onboarding request:\n"
        f"  team        : {state.get('team_name')}\n"
        f"  business unit: {state.get('business_unit')}\n"
        f"  environment : {state.get('target_environment')}\n"
        f"  repo        : {state.get('repo_url')}@{state.get('repo_branch','main')}\n"
        f"  requested by: {state.get('requestor_email')}\n\n"
        f"Plan their self-hosted build-agent infrastructure end-to-end."
    )
