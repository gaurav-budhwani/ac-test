"""
Dependency resolver.

Translates `DetectedStack` entries from the scanner into a flat list of
`RuntimeRequirement` entries that describe what the build-agent VM must have
installed before pipelines can run.

The mapping table is intentionally **declarative** so it can be reviewed by
security / platform engineering during change-control, and so the LLM does
*not* invent SDK versions on the fly.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

from agent.state import DetectedStack, RuntimeRequirement


@dataclass(frozen=True)
class _ResolutionRule:
    language: str
    sdk_package: str                    # e.g. "dotnet-sdk-8.0"
    apt_packages: tuple[str, ...] = ()
    default_version: str = ""
    docker_required: bool = True
    notes: str = ""


# Single source of truth — keep alphabetised so reviewers can diff easily.
_RULES: dict[str, _ResolutionRule] = {
    "dotnet:6.0": _ResolutionRule(
        "dotnet", "dotnet-sdk-6.0", ("ca-certificates", "libicu74"),
        default_version="6.0",
    ),
    "dotnet:8.0": _ResolutionRule(
        "dotnet", "dotnet-sdk-8.0", ("ca-certificates", "libicu74"),
        default_version="8.0",
    ),
    "dotnet:9.0": _ResolutionRule(
        "dotnet", "dotnet-sdk-9.0", ("ca-certificates", "libicu74"),
        default_version="9.0",
    ),
    "java:17":   _ResolutionRule("java", "openjdk-17-jdk", ("maven",),
                                 default_version="17"),
    "java:21":   _ResolutionRule("java", "openjdk-21-jdk", ("maven",),
                                 default_version="21"),
    "node:18":   _ResolutionRule("node", "nodejs",
                                 ("build-essential",), default_version="18"),
    "node:20":   _ResolutionRule("node", "nodejs",
                                 ("build-essential",), default_version="20"),
    "node:22":   _ResolutionRule("node", "nodejs",
                                 ("build-essential",), default_version="22"),
    "python:3.10": _ResolutionRule("python", "python3.10",
                                   ("python3.10-venv", "python3-pip"),
                                   default_version="3.10"),
    "python:3.11": _ResolutionRule("python", "python3.11",
                                   ("python3.11-venv", "python3-pip"),
                                   default_version="3.11"),
    "python:3.12": _ResolutionRule("python", "python3.12",
                                   ("python3.12-venv", "python3-pip"),
                                   default_version="3.12"),
    "go:1.22":  _ResolutionRule("go", "golang-1.22", default_version="1.22"),
    "go:1.23":  _ResolutionRule("go", "golang-1.23", default_version="1.23"),
}

# Fallbacks when the scanner didn't pin a version.
_LANG_FALLBACK = {
    "dotnet": "dotnet:8.0",
    "java": "java:21",
    "node": "node:20",
    "python": "python:3.11",
    "go": "go:1.22",
}


# Azure VM SKU recommendations. Kept here (not in policy_engine) because this
# is a *fit* decision; policy_engine only checks whether the SKU is *allowed*.
_VM_SKU_MATRIX = {
    # (needs_gpu, heavy_workload)
    (False, False): "Standard_D4s_v5",
    (False, True):  "Standard_D8s_v5",
    (True,  False): "Standard_NC4as_T4_v3",   # 1 x T4, good for inference
    (True,  True):  "Standard_NC24ads_A100_v4",
}


class DependencyResolver:
    """Pure function wrapped in a class for testability and future caching."""

    def resolve(self, stacks: Iterable[DetectedStack]) -> tuple[
            list[RuntimeRequirement], bool, str]:
        """Returns (requirements, needs_gpu, recommended_vm_sku)."""
        requirements: list[RuntimeRequirement] = []
        seen_keys: set[str] = set()
        needs_gpu = False
        heavy = False

        for stack in stacks:
            if stack.get("requires_gpu"):
                needs_gpu = True
            # ".NET 8" projects ARE heavy if they pull EF + ASP.NET; the
            # framework signal is enough here.
            if stack.get("framework") in {"spring-boot", "nextjs", "django"}:
                heavy = True

            rule_key = self._pick_rule_key(stack)
            if not rule_key or rule_key in seen_keys:
                continue
            seen_keys.add(rule_key)
            rule = _RULES[rule_key]

            requirements.append(RuntimeRequirement(
                kind="sdk",
                name=rule.sdk_package,
                version=rule.default_version,
                rationale=f"Detected {stack.get('language')} stack at "
                          f"{stack.get('manifest_path')}",
            ))
            for apt in rule.apt_packages:
                requirements.append(RuntimeRequirement(
                    kind="apt", name=apt, version=None,
                    rationale=f"System dependency for {rule.sdk_package}",
                ))
            if rule.docker_required:
                # Deduped below; resolver may add Docker many times.
                requirements.append(RuntimeRequirement(
                    kind="docker", name="docker-ce", version=None,
                    rationale="Containerised build steps are standard for "
                              f"{rule.language} pipelines",
                ))

        # GPU adds an NVIDIA driver + container toolkit.
        if needs_gpu:
            requirements.append(RuntimeRequirement(
                kind="gpu_driver", name="nvidia-driver-550", version="550",
                rationale="ML workload detected (torch/tensorflow/etc.)",
            ))
            requirements.append(RuntimeRequirement(
                kind="apt", name="nvidia-container-toolkit", version=None,
                rationale="Enables GPU access from inside containers",
            ))

        # Azure DevOps agent itself.
        requirements.append(RuntimeRequirement(
            kind="service", name="azure-pipelines-agent", version="latest",
            rationale="The self-hosted agent service that pulls jobs from ADO",
        ))

        recommended_sku = _VM_SKU_MATRIX[(needs_gpu, heavy)]
        return _dedupe(requirements), needs_gpu, recommended_sku

    # ------------------------------------------------------------------ #

    def _pick_rule_key(self, stack: DetectedStack) -> str | None:
        lang = stack.get("language")
        if lang in {"unknown", "docker", None}:
            return None
        version = stack.get("runtime_version")
        if version:
            # Normalise "3.11.4" -> "3.11", "1.22.0" -> "1.22", "8.0" -> "8.0"
            parts = version.split(".")
            if lang == "java":
                short = parts[0]                # "17", "21"
            else:
                short = ".".join(parts[:2])
            key = f"{lang}:{short}"
            if key in _RULES:
                return key
        # Fallback when version missing or unsupported.
        return _LANG_FALLBACK.get(lang)


def _dedupe(reqs: list[RuntimeRequirement]) -> list[RuntimeRequirement]:
    seen: set[tuple[str, str]] = set()
    out: list[RuntimeRequirement] = []
    for r in reqs:
        key = (r["kind"], r["name"])
        if key in seen:
            continue
        seen.add(key)
        out.append(r)
    return out
