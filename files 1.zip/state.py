"""
Shared state for the Build Infra Agent LangGraph workflow.

All nodes read/write this single TypedDict. Each field tracks one phase
of the build-agent provisioning pipeline.
"""
from __future__ import annotations

from typing import Annotated, Any, Literal, TypedDict
from operator import add


# ----------------------------- domain types --------------------------------


class DetectedStack(TypedDict, total=False):
    """A single language/framework signature found in the repo."""
    language: str                        # "dotnet" | "java" | "node" | "python" | "go"
    framework: str | None                # e.g. "aspnetcore", "spring-boot", "fastapi"
    runtime_version: str | None          # e.g. "8.0", "21", "20.11.0", "3.11"
    package_manager: str | None          # "nuget" | "maven" | "npm" | "pip" | "poetry"
    manifest_path: str                   # repo-relative path of the file detected
    requires_gpu: bool                   # ML / CUDA workloads
    extras: dict[str, Any]               # free-form bag for scanner specifics


class RuntimeRequirement(TypedDict):
    """A concrete OS-level or SDK-level dependency the agent VM must have."""
    kind: Literal["sdk", "apt", "pip", "docker", "service", "gpu_driver"]
    name: str
    version: str | None
    rationale: str                       # why the resolver added it


class ModuleSelection(TypedDict):
    """An entry pulled from the approved Terraform module registry."""
    module_name: str
    source: str                          # registry path
    version: str
    inputs: dict[str, Any]


class PolicyViolation(TypedDict):
    rule_id: str
    severity: Literal["error", "warn"]
    message: str
    offending_module: str | None


# ----------------------------- graph state ---------------------------------


class AgentState(TypedDict, total=False):
    """
    State threaded through every LangGraph node.

    Annotated[..., add] fields are *accumulators* — when a node returns a list
    for that key, LangGraph appends instead of overwriting.
    """
    # --- inputs ---
    team_name: str
    repo_url: str
    repo_branch: str
    requestor_email: str
    business_unit: str
    target_environment: Literal["dev", "test", "prod"]

    # --- scan phase ---
    detected_stacks: list[DetectedStack]
    scanner_warnings: Annotated[list[str], add]

    # --- resolve phase ---
    runtime_requirements: list[RuntimeRequirement]
    needs_gpu: bool
    recommended_vm_sku: str

    # --- plan phase ---
    selected_modules: list[ModuleSelection]
    terraform_hcl: str
    terraform_plan_summary: str

    # --- policy phase ---
    policy_violations: list[PolicyViolation]
    policy_passed: bool

    # --- emit phase ---
    pull_request_url: str | None
    approval_status: Literal["pending", "approved", "rejected", "auto-approved"]

    # --- conversation / tool-calling memory ---
    messages: Annotated[list[dict[str, Any]], add]
    iteration: int
    final_summary: str
