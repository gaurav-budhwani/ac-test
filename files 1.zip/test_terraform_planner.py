"""Tests for tools/terraform_planner.py."""
from __future__ import annotations

from agent.state import ModuleSelection
from tools.terraform_planner import render_hcl, TerraformPlanner


def _sample() -> list[ModuleSelection]:
    return [
        ModuleSelection(
            module_name="vnet",
            source="app.terraform.io/contoso/vnet/azurerm",
            version="3.4.1",
            inputs={
                "name": "vnet-x",
                "address_space": ["10.40.0.0/16"],
                "subnets": [{"name": "agents", "cidr": "10.40.1.0/24"}],
                "resource_group_name": "rg-x",
            },
        ),
        ModuleSelection(
            module_name="vmss_linux",
            source="app.terraform.io/contoso/vmss-linux/azurerm",
            version="5.1.0",
            inputs={
                "name": "vmss-x", "resource_group_name": "rg-x",
                "subnet_id": "${module.vnet.subnet_ids[\"agents\"]}",
                "sku": "Standard_D4s_v5", "instance_count": 2,
                "key_vault_id": "${module.key_vault.id}",
                "user_assigned_identity_id": "${module.managed_identity.id}",
                "cloud_init_b64": "aGVsbG8=",
            },
        ),
    ]


def test_hcl_contains_terraform_header() -> None:
    hcl = render_hcl(_sample(), tags={"environment": "dev"})
    assert "terraform {" in hcl
    assert 'required_version = ">= 1.7.0"' in hcl


def test_module_block_renders() -> None:
    hcl = render_hcl(_sample(), tags={"environment": "dev"})
    assert 'module "vnet"' in hcl
    assert 'source  = "app.terraform.io/contoso/vnet/azurerm"' in hcl
    assert 'version = "3.4.1"' in hcl


def test_interpolations_unquoted() -> None:
    hcl = render_hcl(_sample(), tags={"environment": "dev"})
    # The interpolation should appear without surrounding quotes.
    assert "module.vnet.subnet_ids" in hcl
    assert '"${module.vnet.subnet_ids' not in hcl


def test_lists_and_maps_pretty_printed() -> None:
    hcl = render_hcl(_sample(), tags={"environment": "dev"})
    # nested subnet map renders as a block
    assert "name = \"agents\"" in hcl
    assert "cidr = \"10.40.1.0/24\"" in hcl


def test_offline_plan_synthesises_summary() -> None:
    hcl = render_hcl(_sample(), tags={"environment": "dev"})
    summary = TerraformPlanner()._synthesise_summary(hcl)
    assert "2 modules" in summary
