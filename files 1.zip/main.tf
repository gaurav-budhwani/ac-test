###############################################################################
# Contoso pre-approved module: vmss-linux
# Versioned independently from the agent. The Build Infra Agent references
# this module by `source` + `version` only — it never modifies its body.
###############################################################################

terraform {
  required_version = ">= 1.7.0"
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 3.110"
    }
  }
}

variable "name"                       { type = string }
variable "resource_group_name"        { type = string }
variable "subnet_id"                  { type = string }
variable "sku"                        { type = string }
variable "instance_count"             { type = number }
variable "key_vault_id"               { type = string }
variable "user_assigned_identity_id"  { type = string }
variable "cloud_init_b64"             { type = string }
variable "min_instances"              { type = number  default = 1 }
variable "max_instances"              { type = number  default = 5 }
variable "spot_enabled"               { type = bool    default = false }
variable "tags"                       { type = map(string)  default = {} }

# Disk encryption set backed by the team's CMK. CMK enforcement is mandatory
# per policy POL-CMK-001.
data "azurerm_key_vault" "kv" {
  # The Key Vault module exposes its id; we look it up to fetch the key URL.
  name                = split("/", var.key_vault_id)[8]
  resource_group_name = var.resource_group_name
}

resource "azurerm_key_vault_key" "disk" {
  name         = "${var.name}-disk-cmk"
  key_vault_id = var.key_vault_id
  key_type     = "RSA"
  key_size     = 4096
  key_opts     = ["decrypt", "encrypt", "unwrapKey", "wrapKey"]
}

resource "azurerm_disk_encryption_set" "this" {
  name                = "${var.name}-des"
  resource_group_name = var.resource_group_name
  location            = data.azurerm_key_vault.kv.location
  key_vault_key_id    = azurerm_key_vault_key.disk.id

  identity {
    type         = "UserAssigned"
    identity_ids = [var.user_assigned_identity_id]
  }
  tags = var.tags
}

resource "azurerm_linux_virtual_machine_scale_set" "this" {
  name                            = var.name
  resource_group_name             = var.resource_group_name
  location                        = data.azurerm_key_vault.kv.location
  sku                             = var.sku
  instances                       = var.instance_count
  admin_username                  = "azagent"
  disable_password_authentication = true
  priority                        = var.spot_enabled ? "Spot" : "Regular"
  eviction_policy                 = var.spot_enabled ? "Deallocate" : null
  custom_data                     = var.cloud_init_b64
  encryption_at_host_enabled      = true
  tags                            = var.tags

  identity {
    type         = "UserAssigned"
    identity_ids = [var.user_assigned_identity_id]
  }

  source_image_reference {
    publisher = "Canonical"
    offer     = "0001-com-ubuntu-server-jammy"
    sku       = "22_04-lts-gen2"
    version   = "latest"
  }

  os_disk {
    storage_account_type   = "Premium_LRS"
    caching                = "ReadWrite"
    disk_encryption_set_id = azurerm_disk_encryption_set.this.id
  }

  # NO public IP — agents reach ADO over the VNet via Private Link.
  network_interface {
    name    = "${var.name}-nic"
    primary = true

    ip_configuration {
      name      = "ipconfig1"
      primary   = true
      subnet_id = var.subnet_id
      # public_ip_address block intentionally omitted; policy POL-004
      # would flag any rendered HCL that includes one.
    }
  }

  admin_ssh_key {
    username   = "azagent"
    public_key = file("${path.module}/files/azagent.pub")
  }
}

resource "azurerm_monitor_autoscale_setting" "this" {
  name                = "${var.name}-autoscale"
  resource_group_name = var.resource_group_name
  location            = data.azurerm_key_vault.kv.location
  target_resource_id  = azurerm_linux_virtual_machine_scale_set.this.id

  profile {
    name = "default"
    capacity {
      default = var.instance_count
      minimum = var.min_instances
      maximum = var.max_instances
    }
    # Scale on ADO queue length via a custom metric; defaults shown for brevity.
    rule {
      metric_trigger {
        metric_name        = "Percentage CPU"
        metric_resource_id = azurerm_linux_virtual_machine_scale_set.this.id
        time_grain         = "PT1M"
        statistic          = "Average"
        time_window        = "PT5M"
        time_aggregation   = "Average"
        operator           = "GreaterThan"
        threshold          = 75
      }
      scale_action {
        direction = "Increase"
        type      = "ChangeCount"
        value     = "1"
        cooldown  = "PT5M"
      }
    }
  }
  tags = var.tags
}

output "id"   { value = azurerm_linux_virtual_machine_scale_set.this.id }
output "name" { value = azurerm_linux_virtual_machine_scale_set.this.name }
