"""Tests for tools/repo_scanner.py."""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from tools.repo_scanner import RepoScanner


@pytest.fixture
def repo(tmp_path: Path) -> Path:
    """Make a fake multi-stack repo on disk."""
    (tmp_path / "api.csproj").write_text("""\
<Project Sdk="Microsoft.NET.Sdk.Web">
  <PropertyGroup><TargetFramework>net8.0</TargetFramework></PropertyGroup>
  <ItemGroup>
    <PackageReference Include="Microsoft.AspNetCore.OpenApi" Version="8.0.0" />
  </ItemGroup>
</Project>
""")
    (tmp_path / "service" / "pom.xml").parent.mkdir(parents=True)
    (tmp_path / "service" / "pom.xml").write_text("""\
<project xmlns="http://maven.apache.org/POM/4.0.0">
  <properties><java.version>21</java.version></properties>
  <dependencies>
    <dependency><groupId>org.springframework.boot</groupId>
                 <artifactId>spring-boot-starter</artifactId></dependency>
  </dependencies>
</project>
""")
    (tmp_path / "web").mkdir()
    (tmp_path / "web" / "package.json").write_text(json.dumps({
        "engines": {"node": "20.11.0"},
        "dependencies": {"next": "^14.0.0", "ioredis": "^5"},
    }))
    (tmp_path / "ml").mkdir()
    (tmp_path / "ml" / "requirements.txt").write_text(
        "fastapi==0.111\ntorch>=2.2\ntransformers\n# comment\n")
    return tmp_path


def test_detects_all_stacks(repo: Path) -> None:
    scanner = RepoScanner()
    stacks = scanner.scan(repo)

    by_lang = {s["language"]: s for s in stacks}
    assert by_lang["dotnet"]["runtime_version"] == "8.0"
    assert by_lang["dotnet"]["framework"] == "aspnetcore"
    assert by_lang["java"]["runtime_version"] == "21"
    assert by_lang["java"]["framework"] == "spring-boot"
    assert by_lang["node"]["framework"] == "nextjs"
    # Python should detect GPU need from torch/transformers
    assert by_lang["python"]["requires_gpu"] is True
    assert by_lang["python"]["framework"] == "fastapi"


def test_handles_bad_manifest(tmp_path: Path) -> None:
    (tmp_path / "package.json").write_text("{ not json")
    stacks = RepoScanner().scan(tmp_path)
    assert any("parse_error" in (s.get("extras") or {}) for s in stacks)


def test_skips_node_modules(tmp_path: Path) -> None:
    junk = tmp_path / "node_modules" / "foo"
    junk.mkdir(parents=True)
    (junk / "package.json").write_text('{"name":"foo"}')
    real = tmp_path / "package.json"
    real.write_text(json.dumps({"engines": {"node": "20"}, "dependencies": {}}))
    stacks = RepoScanner().scan(tmp_path)
    assert len(stacks) == 1
    assert stacks[0]["manifest_path"] == "package.json"
