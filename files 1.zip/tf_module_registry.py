"""
Terraform module registry.

Holds metadata about the pre-approved, security-hardened Terraform modules
the platform team has published to its private registry. The agent is *only*
allowed to compose infrastructure out of these — it can NOT write raw HCL
that references arbitrary providers or modules.

In production this would be backed by the actual private TF registry API.
For this reference implementation we hard-code an in-memory catalogue so the
agent is fully testable offline.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from agent.state import ModuleSelection, RuntimeRequirement


@dataclass(frozen=True)
class ApprovedModule:
    name: str
    source: str
    version: str
    purpose: str
    required_inputs: tuple[str, ...] = ()
    optional_inputs: tuple[str, ...] = ()
    # Compliance traits the policy engine will check against:
    provides_private_endpoint: bool = False
    enforces_cmk: bool = False
    tags: tuple[str, ...] = field(default_factory=tuple)


# Curated catalogue. Versions are pinned because the agent should be
# reproducible — drift here is a change-control event, not an LLM decision.
CATALOGUE: dict[str, ApprovedModule] = {
    "vnet": ApprovedModule(
        name="vnet",
        source="app.terraform.io/contoso/vnet/azurerm",
        version="3.4.1",
        purpose="Hub-spoke compatible virtual network with subnets",
        required_inputs=("name", "address_space", "subnets", "resource_group_name"),
        optional_inputs=("dns_servers", "ddos_protection_plan_id"),
        provides_private_endpoint=False,
        tags=("network",),
    ),
    "nsg": ApprovedModule(
        name="nsg",
        source="app.terraform.io/contoso/nsg/azurerm",
        version="2.1.0",
        purpose="Network security group with deny-all default + curated allow rules",
        required_inputs=("name", "resource_group_name", "subnet_id"),
        optional_inputs=("allow_ado_outbound", "allow_artifact_feeds"),
        tags=("network", "security"),
    ),
    "key_vault": ApprovedModule(
        name="key_vault",
        source="app.terraform.io/contoso/keyvault/azurerm",
        version="4.0.2",
        purpose="Customer-managed-key vault with private endpoint and RBAC",
        required_inputs=("name", "resource_group_name", "subnet_id_for_pe"),
        optional_inputs=("purge_protection_enabled",),
        provides_private_endpoint=True,
        enforces_cmk=True,
        tags=("security", "secrets"),
    ),
    "managed_identity": ApprovedModule(
        name="managed_identity",
        source="app.terraform.io/contoso/managed-identity/azurerm",
        version="1.3.0",
        purpose="User-assigned identity for the agent VMs",
        required_inputs=("name", "resource_group_name"),
        tags=("identity",),
    ),
    "log_analytics": ApprovedModule(
        name="log_analytics",
        source="app.terraform.io/contoso/log-analytics/azurerm",
        version="2.2.1",
        purpose="Workspace with 90-day retention and platform diagnostic settings",
        required_inputs=("name", "resource_group_name"),
        tags=("observability",),
    ),
    "vmss_linux": ApprovedModule(
        name="vmss_linux",
        source="app.terraform.io/contoso/vmss-linux/azurerm",
        version="5.1.0",
        purpose="Linux VMSS with cloud-init, system-assigned identity disabled, "
                "CMK OS-disk encryption, no public IP, attached NSG",
        required_inputs=("name", "resource_group_name", "subnet_id",
                          "sku", "instance_count", "key_vault_id",
                          "user_assigned_identity_id", "cloud_init_b64"),
        optional_inputs=("min_instances", "max_instances", "spot_enabled"),
        enforces_cmk=True,
        tags=("compute",),
    ),
    "vmss_gpu": ApprovedModule(
        name="vmss_gpu",
        source="app.terraform.io/contoso/vmss-gpu/azurerm",
        version="2.0.4",
        purpose="GPU-enabled VMSS variant with NVIDIA driver extension pre-baked",
        required_inputs=("name", "resource_group_name", "subnet_id",
                          "sku", "instance_count", "key_vault_id",
                          "user_assigned_identity_id", "cloud_init_b64"),
        optional_inputs=("min_instances", "max_instances", "driver_version"),
        enforces_cmk=True,
        tags=("compute", "gpu"),
    ),
}


class TerraformModuleRegistry:
    """Read-only interface the agent uses via tool-calling."""

    def list_modules(self) -> list[dict[str, Any]]:
        return [
            {"name": m.name, "purpose": m.purpose, "version": m.version,
             "required_inputs": list(m.required_inputs),
             "optional_inputs": list(m.optional_inputs)}
            for m in CATALOGUE.values()
        ]

    def get(self, name: str) -> ApprovedModule:
        if name not in CATALOGUE:
            raise KeyError(f"Module '{name}' is not in the approved registry. "
                           f"Available: {sorted(CATALOGUE)}")
        return CATALOGUE[name]

    # ---------------------------------------------------------------- #
    # composition helpers
    # ---------------------------------------------------------------- #

    def compose_default_topology(
        self,
        team_name: str,
        business_unit: str,
        environment: str,
        recommended_sku: str,
        needs_gpu: bool,
        requirements: list[RuntimeRequirement],
    ) -> list[ModuleSelection]:
        """
        Build a *deterministic* baseline selection. The LLM can mutate the
        inputs after this — but cannot skip security-mandatory modules like
        Key Vault, Log Analytics, or Managed Identity.
        """
        base_name = _sanitise(f"bia-{business_unit}-{team_name}-{environment}")
        rg_input = f"rg-{base_name}"

        cloud_init = _render_cloud_init_b64(requirements)

        selections: list[ModuleSelection] = [
            self._sel("vnet", inputs={
                "name": f"vnet-{base_name}",
                "address_space": ["10.40.0.0/16"],
                "subnets": [{"name": "agents", "cidr": "10.40.1.0/24"},
                            {"name": "pe",     "cidr": "10.40.2.0/27"}],
                "resource_group_name": rg_input,
            }),
            self._sel("nsg", inputs={
                "name": f"nsg-{base_name}",
                "resource_group_name": rg_input,
                "subnet_id": "${module.vnet.subnet_ids[\"agents\"]}",
                "allow_ado_outbound": True,
            }),
            self._sel("managed_identity", inputs={
                "name": f"id-{base_name}",
                "resource_group_name": rg_input,
            }),
            self._sel("log_analytics", inputs={
                "name": f"law-{base_name}",
                "resource_group_name": rg_input,
            }),
            self._sel("key_vault", inputs={
                "name": f"kv-{base_name}"[:24],   # KV name max length
                "resource_group_name": rg_input,
                "subnet_id_for_pe": "${module.vnet.subnet_ids[\"pe\"]}",
                "purge_protection_enabled": environment == "prod",
            }),
        ]

        compute_module = "vmss_gpu" if needs_gpu else "vmss_linux"
        selections.append(self._sel(compute_module, inputs={
            "name": f"vmss-{base_name}",
            "resource_group_name": rg_input,
            "subnet_id": "${module.vnet.subnet_ids[\"agents\"]}",
            "sku": recommended_sku,
            "instance_count": 2 if environment != "prod" else 4,
            "key_vault_id": "${module.key_vault.id}",
            "user_assigned_identity_id": "${module.managed_identity.id}",
            "cloud_init_b64": cloud_init,
            "min_instances": 1,
            "max_instances": 10 if environment == "prod" else 5,
        }))
        return selections

    def _sel(self, name: str, inputs: dict[str, Any]) -> ModuleSelection:
        m = CATALOGUE[name]
        # Surface a useful error early rather than at terraform plan time.
        missing = [k for k in m.required_inputs if k not in inputs]
        if missing:
            raise ValueError(
                f"Module '{name}' missing required inputs: {missing}")
        return ModuleSelection(
            module_name=m.name, source=m.source, version=m.version, inputs=inputs)


# ------------------------------ helpers -------------------------------------


def _sanitise(s: str) -> str:
    out = "".join(c if c.isalnum() else "-" for c in s.lower())
    while "--" in out:
        out = out.replace("--", "-")
    return out.strip("-")


def _render_cloud_init_b64(reqs: list[RuntimeRequirement]) -> str:
    """Render the cloud-init that installs every resolved requirement."""
    import base64
    lines = ["#cloud-config", "package_update: true", "packages:"]
    for r in reqs:
        if r["kind"] in {"apt", "sdk"}:
            lines.append(f"  - {r['name']}")
    # ADO agent registration is a runcmd, not a package.
    lines += [
        "runcmd:",
        "  - mkdir -p /opt/azagent && cd /opt/azagent",
        # In production, the token comes from Key Vault via the MSI.
        "  - su -c 'curl -sL "
        "$ADO_AGENT_DL_URL | tar xz' azagent",
        "  - su -c './config.sh --unattended --url $ADO_ORG_URL "
        "--auth pat --token $ADO_PAT --pool $ADO_POOL --acceptTeeEula' azagent",
        "  - ./svc.sh install && ./svc.sh start",
    ]
    return base64.b64encode("\n".join(lines).encode()).decode()
