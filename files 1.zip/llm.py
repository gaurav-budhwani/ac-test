"""
Azure OpenAI client wrapper.

Centralises configuration and tool-calling boilerplate so the graph nodes
stay focused on workflow logic. Uses the official `openai` SDK in
Azure-endpoint mode.

Env vars:
    AZURE_OPENAI_ENDPOINT      e.g. https://my-aoai.openai.azure.com
    AZURE_OPENAI_API_KEY       (or use AAD via DefaultAzureCredential)
    AZURE_OPENAI_DEPLOYMENT    deployment name, e.g. "gpt-4o"
    AZURE_OPENAI_API_VERSION   default "2024-08-01-preview"
"""
from __future__ import annotations

import json
import os
from typing import Any

from openai import AzureOpenAI


SYSTEM_PROMPT = """\
You are the Build Infra Agent for Contoso's central Azure DevOps platform.

Your job is to plan a self-hosted ADO build-agent VMSS for an onboarding team.
You operate by calling tools. You do NOT invent infrastructure. You do NOT
write raw Terraform. You compose only modules returned by `list_modules`.

Workflow you must follow (each tool exactly once unless the user pushes back):
  1. scan_repo(repo_url) — discover the team's tech stack.
  2. resolve_dependencies(stacks) — turn stacks into SDK / OS requirements.
  3. list_modules() and then propose_topology(...) — pick approved building blocks.
  4. render_and_plan(selections, tags) — render HCL and produce a plan summary.
  5. check_policy(selections, hcl, tags, environment) — enforce org standards.
     If there are blocking violations, revise the selections and retry policy.
  6. emit_summary(...) — explain the plan to the requestor in plain English.

Constraints:
  * Never bypass the policy engine. If you cannot satisfy it, say so honestly.
  * Always include managed_identity, key_vault, log_analytics, and nsg.
  * GPU VMSS only when `needs_gpu` is true.
  * Use the recommended_vm_sku from the resolver unless policy rejects it.
  * Tag every plan with business_unit, cost_center, environment,
    data_classification, owner_email.
"""


class AzureOpenAIChat:
    def __init__(
        self,
        endpoint: str | None = None,
        api_key: str | None = None,
        deployment: str | None = None,
        api_version: str = "2024-08-01-preview",
    ) -> None:
        self.endpoint = endpoint or os.environ["AZURE_OPENAI_ENDPOINT"]
        self.deployment = deployment or os.environ["AZURE_OPENAI_DEPLOYMENT"]
        api_key = api_key or os.environ.get("AZURE_OPENAI_API_KEY")
        if not api_key:
            # In production prefer AAD; this branch is illustrative.
            raise RuntimeError(
                "AZURE_OPENAI_API_KEY not set. For prod, swap in "
                "azure.identity.DefaultAzureCredential and pass "
                "azure_ad_token_provider= to AzureOpenAI().")
        self.client = AzureOpenAI(
            azure_endpoint=self.endpoint,
            api_key=api_key,
            api_version=api_version,
        )

    def chat(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        temperature: float = 0.0,
    ) -> dict[str, Any]:
        """One round of completion with optional tool definitions."""
        resp = self.client.chat.completions.create(
            model=self.deployment,
            messages=messages,
            tools=tools,
            temperature=temperature,
        )
        msg = resp.choices[0].message
        out: dict[str, Any] = {"role": "assistant", "content": msg.content or ""}
        if msg.tool_calls:
            out["tool_calls"] = [
                {"id": tc.id, "type": "function",
                 "function": {"name": tc.function.name,
                              "arguments": tc.function.arguments}}
                for tc in msg.tool_calls
            ]
        return out

    @staticmethod
    def tool_result_message(tool_call_id: str, name: str, result: Any) -> dict[str, Any]:
        return {
            "role": "tool",
            "tool_call_id": tool_call_id,
            "name": name,
            "content": json.dumps(result, default=str),
        }
