"""
Terraform planner.

Two responsibilities:

1. Render a complete root-module HCL file from a list of `ModuleSelection`
   entries. The output is deterministic and review-friendly so it can be
   committed straight to a PR.

2. Optionally shell out to `terraform init && terraform plan -no-color` and
   capture the human-readable diff. In test mode (no `terraform` on PATH)
   we synthesise a fake summary so the graph still completes end-to-end.
"""
from __future__ import annotations

import json
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import Any

from agent.state import ModuleSelection


# ---------------------------- HCL rendering --------------------------------


def render_hcl(
    selections: list[ModuleSelection],
    tags: dict[str, str],
    location: str = "eastus2",
) -> str:
    """Produce a single main.tf string."""
    blocks: list[str] = [
        _terraform_header(),
        _provider_block(),
        _locals_block(tags),
        _resource_group_block(tags, location),
    ]
    for sel in selections:
        blocks.append(_module_block(sel))
    return "\n\n".join(blocks) + "\n"


def _terraform_header() -> str:
    return (
        'terraform {\n'
        '  required_version = ">= 1.7.0"\n'
        '  required_providers {\n'
        '    azurerm = {\n'
        '      source  = "hashicorp/azurerm"\n'
        '      version = "~> 3.110"\n'
        '    }\n'
        '  }\n'
        '  backend "azurerm" {}\n'
        '}'
    )


def _provider_block() -> str:
    return (
        'provider "azurerm" {\n'
        '  features {\n'
        '    key_vault {\n'
        '      purge_soft_delete_on_destroy = false\n'
        '    }\n'
        '  }\n'
        '}'
    )


def _locals_block(tags: dict[str, str]) -> str:
    return "locals {\n  tags = " + _to_hcl(tags, indent=2) + "\n}"


def _resource_group_block(tags: dict[str, str], location: str) -> str:
    rg = f"rg-{tags.get('business_unit','bu')}-{tags.get('environment','dev')}"
    return (
        f'resource "azurerm_resource_group" "main" {{\n'
        f'  name     = "{rg}"\n'
        f'  location = "{location}"\n'
        f'  tags     = local.tags\n'
        f'}}'
    )


def _module_block(sel: ModuleSelection) -> str:
    body_lines = [
        f'  source  = "{sel["source"]}"',
        f'  version = "{sel["version"]}"',
    ]
    for k, v in sel["inputs"].items():
        body_lines.append(f"  {k} = {_to_hcl(v, indent=2)}")
    body_lines.append("  tags = local.tags")
    return f'module "{sel["module_name"]}" {{\n' + "\n".join(body_lines) + "\n}"


def _to_hcl(value: Any, indent: int = 0) -> str:
    """Convert a Python value to an HCL literal. Handles interpolation strings."""
    pad = " " * indent
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, (int, float)):
        return str(value)
    if value is None:
        return "null"
    if isinstance(value, str):
        # Strings beginning with "${" are HCL interpolations — emit unquoted.
        if value.startswith("${") and value.endswith("}"):
            return value[2:-1]
        return json.dumps(value)
    if isinstance(value, list):
        inner = ",\n".join(pad + "  " + _to_hcl(v, indent + 2) for v in value)
        return "[\n" + inner + "\n" + pad + "]"
    if isinstance(value, dict):
        items = []
        for k, v in value.items():
            items.append(f"{pad}  {k} = {_to_hcl(v, indent + 2)}")
        return "{\n" + "\n".join(items) + "\n" + pad + "}"
    raise TypeError(f"Cannot serialise {type(value).__name__} to HCL")


# ---------------------------- terraform plan -------------------------------


class TerraformPlanner:
    """Wraps the `terraform` CLI. Safe to use in unit tests (falls back)."""

    def plan(self, hcl: str) -> str:
        """Returns a string summary of `terraform plan`."""
        if shutil.which("terraform") is None:
            return self._synthesise_summary(hcl)

        with tempfile.TemporaryDirectory(prefix="bia-plan-") as tmp:
            workdir = Path(tmp)
            (workdir / "main.tf").write_text(hcl)
            try:
                subprocess.run(
                    ["terraform", "init", "-backend=false", "-input=false"],
                    cwd=workdir, check=True, capture_output=True, timeout=120,
                )
                result = subprocess.run(
                    ["terraform", "plan", "-no-color", "-input=false",
                     "-lock=false"],
                    cwd=workdir, check=False, capture_output=True, timeout=300,
                )
            except subprocess.TimeoutExpired:
                return "terraform plan timed out after 5 minutes"
            return (result.stdout + b"\n--- STDERR ---\n" + result.stderr).decode(
                errors="replace")

    @staticmethod
    def _synthesise_summary(hcl: str) -> str:
        # Count `module "..."` declarations as a proxy for resource creation.
        import re as _re
        modules = _re.findall(r'module "([^"]+)"', hcl)
        return (
            "[offline terraform plan synthesis]\n"
            f"Plan: {len(modules)} modules to instantiate.\n"
            "Modules: " + ", ".join(modules) + "\n"
            "No backend was initialised; this summary is for review only."
        )
