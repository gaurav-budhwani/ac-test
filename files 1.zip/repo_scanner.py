"""
Repo scanner.

Walks a checked-out repository and produces a list of `DetectedStack` entries
by parsing language-specific manifest files. Only does *static* parsing — no
network calls, no code execution.

Supported manifests:
  * csproj / *.fsproj / global.json   -> .NET
  * pom.xml / build.gradle(.kts)       -> Java / Kotlin
  * package.json                       -> Node.js
  * requirements.txt / pyproject.toml  -> Python
  * Dockerfile                         -> base-image hint
  * go.mod                             -> Go
"""
from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Iterable

# defusedxml is hardened against XML attacks (XXE, billion-laughs).
# Crucial because we ingest untrusted pom.xml / csproj from arbitrary repos.
from defusedxml import ElementTree as SafeET

try:
    import tomllib  # py311+
except ModuleNotFoundError:                        # pragma: no cover
    import tomli as tomllib                        # type: ignore

from agent.state import DetectedStack


# Manifest filename -> parser dispatch. Globs handled separately below.
_DISPATCH: dict[str, str] = {
    "package.json": "_parse_node",
    "requirements.txt": "_parse_pip",
    "pyproject.toml": "_parse_pyproject",
    "pom.xml": "_parse_maven",
    "build.gradle": "_parse_gradle",
    "build.gradle.kts": "_parse_gradle",
    "go.mod": "_parse_go",
    "Dockerfile": "_parse_dockerfile",
    "global.json": "_parse_global_json",
}


# Heuristic: any of these substrings in a Python dep => GPU agent needed.
_GPU_HINTS = {"torch", "tensorflow", "cupy", "jax", "transformers", "vllm", "xgboost-gpu"}


class RepoScanner:
    """Stateless scanner; instantiate once per request."""

    MAX_FILE_BYTES = 2 * 1024 * 1024            # don't slurp giant lockfiles
    MAX_FILES_SCANNED = 5_000                   # protect against monorepos

    def scan(self, repo_root: str | Path) -> list[DetectedStack]:
        root = Path(repo_root).resolve()
        if not root.is_dir():
            raise ValueError(f"repo_root is not a directory: {root}")

        stacks: list[DetectedStack] = []
        seen = 0
        for path in self._iter_manifest_files(root):
            seen += 1
            if seen > self.MAX_FILES_SCANNED:
                break
            try:
                stacks.extend(self._dispatch(path, root))
            except Exception as exc:                                # noqa: BLE001
                # Never crash the whole scan on one bad manifest;
                # surface it as a warning the agent can show the user.
                stacks.append(DetectedStack(
                    language="unknown",
                    framework=None,
                    runtime_version=None,
                    package_manager=None,
                    manifest_path=str(path.relative_to(root)),
                    requires_gpu=False,
                    extras={"parse_error": str(exc)},
                ))
        return _deduplicate(stacks)

    # ------------------------------------------------------------------ #
    # discovery
    # ------------------------------------------------------------------ #

    def _iter_manifest_files(self, root: Path) -> Iterable[Path]:
        # Skip the obvious noise — saves both time and parse failures.
        skip_dirs = {".git", "node_modules", "venv", ".venv", "dist", "build",
                     "target", "obj", "bin", "__pycache__"}
        for path in root.rglob("*"):
            if not path.is_file():
                continue
            if any(part in skip_dirs for part in path.parts):
                continue
            if path.stat().st_size > self.MAX_FILE_BYTES:
                continue
            if path.name in _DISPATCH:
                yield path
            elif path.suffix in {".csproj", ".fsproj"}:
                yield path

    def _dispatch(self, path: Path, root: Path) -> list[DetectedStack]:
        if path.suffix in {".csproj", ".fsproj"}:
            return self._parse_csproj(path, root)
        method = _DISPATCH[path.name]
        return getattr(self, method)(path, root)

    # ------------------------------------------------------------------ #
    # individual parsers
    # ------------------------------------------------------------------ #

    def _parse_csproj(self, path: Path, root: Path) -> list[DetectedStack]:
        tree = SafeET.parse(path)
        # csproj XML has no namespace; strip it just in case.
        tfm = None
        framework = None
        for elem in tree.iter():
            tag = elem.tag.split("}")[-1]
            if tag == "TargetFramework" and elem.text:
                tfm = elem.text.strip()
            elif tag == "PackageReference":
                include = elem.attrib.get("Include", "")
                if include.startswith("Microsoft.AspNetCore"):
                    framework = "aspnetcore"
                elif include.startswith("Microsoft.EntityFrameworkCore"):
                    framework = framework or "efcore"
        version = _net_tfm_to_version(tfm) if tfm else None
        return [DetectedStack(
            language="dotnet",
            framework=framework,
            runtime_version=version,
            package_manager="nuget",
            manifest_path=str(path.relative_to(root)),
            requires_gpu=False,
            extras={"target_framework": tfm},
        )]

    def _parse_global_json(self, path: Path, root: Path) -> list[DetectedStack]:
        data = json.loads(path.read_text())
        version = (data.get("sdk") or {}).get("version")
        return [DetectedStack(
            language="dotnet", framework=None, runtime_version=version,
            package_manager="nuget", manifest_path=str(path.relative_to(root)),
            requires_gpu=False, extras={"source": "global.json"},
        )]

    def _parse_maven(self, path: Path, root: Path) -> list[DetectedStack]:
        # Maven uses default xmlns="http://maven.apache.org/POM/4.0.0"; handle both.
        text = path.read_text()
        # Cheap namespace strip so XPath queries stay readable.
        text = re.sub(r'\sxmlns="[^"]+"', "", text, count=1)
        tree = SafeET.fromstring(text)
        java_version = (
            tree.findtext(".//properties/java.version")
            or tree.findtext(".//properties/maven.compiler.target")
            or tree.findtext(".//properties/maven.compiler.release")
        )
        framework = None
        for dep in tree.findall(".//dependency"):
            gid = dep.findtext("groupId") or ""
            if gid.startswith("org.springframework.boot"):
                framework = "spring-boot"
                break
            if gid.startswith("io.quarkus"):
                framework = "quarkus"
                break
        return [DetectedStack(
            language="java", framework=framework, runtime_version=java_version,
            package_manager="maven", manifest_path=str(path.relative_to(root)),
            requires_gpu=False, extras={},
        )]

    def _parse_gradle(self, path: Path, root: Path) -> list[DetectedStack]:
        # Gradle files aren't safely parseable without a JVM; do a regex sniff.
        text = path.read_text()
        java_version = None
        m = re.search(r'(?:sourceCompatibility|jvmTarget)\s*=?\s*[\'"]?(\d+(?:\.\d+)?)',
                      text)
        if m:
            java_version = m.group(1)
        framework = None
        if "org.springframework.boot" in text:
            framework = "spring-boot"
        elif "io.quarkus" in text:
            framework = "quarkus"
        return [DetectedStack(
            language="java", framework=framework, runtime_version=java_version,
            package_manager="gradle", manifest_path=str(path.relative_to(root)),
            requires_gpu=False, extras={},
        )]

    def _parse_node(self, path: Path, root: Path) -> list[DetectedStack]:
        data = json.loads(path.read_text())
        engines = data.get("engines") or {}
        node_version = engines.get("node")
        deps = {**(data.get("dependencies") or {}), **(data.get("devDependencies") or {})}
        framework = None
        if "next" in deps:
            framework = "nextjs"
        elif "express" in deps:
            framework = "express"
        elif "@nestjs/core" in deps:
            framework = "nestjs"
        elif "fastify" in deps:
            framework = "fastify"
        return [DetectedStack(
            language="node", framework=framework, runtime_version=node_version,
            package_manager="npm", manifest_path=str(path.relative_to(root)),
            requires_gpu=False,
            extras={"redis_client": "redis" in deps or "ioredis" in deps},
        )]

    def _parse_pip(self, path: Path, root: Path) -> list[DetectedStack]:
        deps: list[str] = []
        for line in path.read_text().splitlines():
            line = line.split("#", 1)[0].strip()
            if line and not line.startswith("-"):
                deps.append(line)
        return [self._build_python_stack(path, root, deps, source="requirements.txt")]

    def _parse_pyproject(self, path: Path, root: Path) -> list[DetectedStack]:
        data = tomllib.loads(path.read_text())
        deps: list[str] = []
        # PEP 621
        project = data.get("project", {})
        deps.extend(project.get("dependencies") or [])
        # Poetry
        poetry = (data.get("tool") or {}).get("poetry", {})
        deps.extend((poetry.get("dependencies") or {}).keys())
        python_version = project.get("requires-python") or (
            (poetry.get("dependencies") or {}).get("python")
        )
        stack = self._build_python_stack(path, root, deps, source="pyproject.toml")
        if python_version:
            stack["runtime_version"] = _clean_pep440(python_version)
        return [stack]

    def _build_python_stack(self, path: Path, root: Path,
                            deps: list[str], source: str) -> DetectedStack:
        lower = {d.split("==")[0].split(">=")[0].split("<")[0].strip().lower()
                 for d in deps}
        framework = None
        if "fastapi" in lower:
            framework = "fastapi"
        elif "django" in lower:
            framework = "django"
        elif "flask" in lower:
            framework = "flask"
        gpu = any(hint in lower for hint in _GPU_HINTS)
        return DetectedStack(
            language="python", framework=framework, runtime_version=None,
            package_manager="pip", manifest_path=str(path.relative_to(root)),
            requires_gpu=gpu,
            extras={"source": source, "dep_count": len(deps), "gpu_hints": sorted(
                _GPU_HINTS & lower)},
        )

    def _parse_go(self, path: Path, root: Path) -> list[DetectedStack]:
        version = None
        for line in path.read_text().splitlines():
            if line.startswith("go "):
                version = line.split()[1]
                break
        return [DetectedStack(
            language="go", framework=None, runtime_version=version,
            package_manager="gomod", manifest_path=str(path.relative_to(root)),
            requires_gpu=False, extras={},
        )]

    def _parse_dockerfile(self, path: Path, root: Path) -> list[DetectedStack]:
        # A Dockerfile alone doesn't define the *agent's* runtime — it defines
        # the *app's* runtime. But the FROM line is still a useful hint when
        # no other manifest is present.
        base = None
        for line in path.read_text().splitlines():
            line = line.strip()
            if line.upper().startswith("FROM "):
                base = line.split()[1]
                break
        gpu = bool(base and ("nvidia" in base.lower() or "cuda" in base.lower()))
        return [DetectedStack(
            language="docker", framework=None, runtime_version=None,
            package_manager=None, manifest_path=str(path.relative_to(root)),
            requires_gpu=gpu, extras={"base_image": base},
        )]


# ---------------------------- helpers --------------------------------------


def _net_tfm_to_version(tfm: str) -> str | None:
    """Map .NET Target-Framework-Moniker to SDK version string."""
    # net8.0 -> 8.0, netcoreapp3.1 -> 3.1, net48 -> 4.8 (framework, not core)
    m = re.match(r"net(?:coreapp)?(\d+)(?:\.(\d+))?", tfm)
    if not m:
        return None
    major, minor = m.group(1), m.group(2) or "0"
    if int(major) >= 5 or tfm.startswith("netcoreapp"):
        return f"{major}.{minor}"
    # net48 -> 4.8 (.NET Framework, legacy)
    if len(major) == 2:
        return f"{major[0]}.{major[1]}"
    return f"{major}.{minor}"


def _clean_pep440(spec: str) -> str:
    """Strip PEP 440 operators so we can show a version cleanly."""
    return re.sub(r"[^0-9.]", "", spec).strip(".") or spec


def _deduplicate(stacks: list[DetectedStack]) -> list[DetectedStack]:
    """Collapse exact duplicates that come from multi-module repos."""
    seen: dict[tuple, DetectedStack] = {}
    for s in stacks:
        key = (s.get("language"), s.get("framework"), s.get("runtime_version"))
        # Keep the first occurrence but OR the gpu flag across siblings.
        if key in seen:
            seen[key]["requires_gpu"] = seen[key]["requires_gpu"] or s["requires_gpu"]
        else:
            seen[key] = s
    return list(seen.values())
