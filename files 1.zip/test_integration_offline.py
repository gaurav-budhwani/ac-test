"""
Integration test: scan → resolve → propose topology → render HCL → policy.

Mocks Azure OpenAI out completely so this test runs offline. Verifies the
deterministic backbone of the agent is correct independent of LLM behaviour.
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from agent.state import AgentState
from agent.tool_registry import IMPLEMENTATIONS


@pytest.fixture
def ml_repo(tmp_path: Path) -> Path:
    (tmp_path / "requirements.txt").write_text(
        "fastapi==0.111\ntorch>=2.2\ntransformers\nuvicorn\n")
    return tmp_path


def test_end_to_end_pipeline_offline(monkeypatch, ml_repo: Path) -> None:
    """Walk every tool in order, as the LLM would, without an LLM."""
    state: AgentState = {
        "team_name": "vision",
        "business_unit": "research",
        "target_environment": "dev",
        "repo_url": "https://dev.azure.com/contoso/_git/vision",
        "repo_branch": "main",
        "requestor_email": "alice@contoso",
        "messages": [],
        "iteration": 0,
    }

    # Replace scan_repo so it skips git clone and reads the temp dir directly.
    from tools.repo_scanner import RepoScanner
    def fake_scan(args, st):
        stacks = RepoScanner().scan(ml_repo)
        st["detected_stacks"] = stacks
        return {"detected_stacks": stacks, "count": len(stacks)}
    monkeypatch.setitem(IMPLEMENTATIONS, "scan_repo", fake_scan)

    # 1. scan
    r = IMPLEMENTATIONS["scan_repo"]({}, state)
    assert r["count"] >= 1
    assert state["detected_stacks"][0]["requires_gpu"] is True

    # 2. resolve
    r = IMPLEMENTATIONS["resolve_dependencies"]({}, state)
    assert state["needs_gpu"] is True
    assert state["recommended_vm_sku"].startswith("Standard_NC")

    # 3. propose topology
    r = IMPLEMENTATIONS["propose_topology"]({}, state)
    names = {s["module_name"] for s in state["selected_modules"]}
    assert {"vnet", "nsg", "managed_identity", "key_vault",
            "log_analytics", "vmss_gpu"}.issubset(names)

    # 4. render + plan
    r = IMPLEMENTATIONS["render_and_plan"]({}, state)
    assert "terraform {" in state["terraform_hcl"]
    assert "vmss_gpu" in state["terraform_hcl"]

    # 5. policy
    r = IMPLEMENTATIONS["check_policy"]({}, state)
    assert state["policy_passed"] is True, state["policy_violations"]

    # 6. emit
    r = IMPLEMENTATIONS["emit_summary"](
        {"summary": "All good — GPU VMSS planned for the ML repo."}, state)
    assert state["approval_status"] in ("auto-approved", "pending")


def test_policy_repair_path(monkeypatch, ml_repo: Path) -> None:
    """If we tamper with the SKU, policy should fail; once fixed it should pass."""
    state: AgentState = {
        "team_name": "vision", "business_unit": "research",
        "target_environment": "prod",
        "repo_url": "https://dev.azure.com/contoso/_git/vision",
        "repo_branch": "main",
        "requestor_email": "alice@contoso",
        "messages": [], "iteration": 0,
    }
    from tools.repo_scanner import RepoScanner
    monkeypatch.setitem(IMPLEMENTATIONS, "scan_repo",
                        lambda a, s: (s.update(detected_stacks=RepoScanner().scan(ml_repo))
                                      or {"count": 1}))

    IMPLEMENTATIONS["scan_repo"]({}, state)
    IMPLEMENTATIONS["resolve_dependencies"]({}, state)
    IMPLEMENTATIONS["propose_topology"]({}, state)

    # Tamper: set a forbidden SKU.
    for sel in state["selected_modules"]:
        if sel["module_name"] == "vmss_gpu":
            sel["inputs"]["sku"] = "Standard_A1_v2"

    IMPLEMENTATIONS["render_and_plan"]({}, state)
    IMPLEMENTATIONS["check_policy"]({}, state)
    assert state["policy_passed"] is False
    assert any(v["rule_id"] == "POL-002" for v in state["policy_violations"])

    # Repair and rerun.
    for sel in state["selected_modules"]:
        if sel["module_name"] == "vmss_gpu":
            sel["inputs"]["sku"] = "Standard_NC4as_T4_v3"
    IMPLEMENTATIONS["render_and_plan"]({}, state)
    IMPLEMENTATIONS["check_policy"]({}, state)
    assert state["policy_passed"] is True
