"""
Tool registry exposed to the LLM.

Each entry has:
  * `spec` — the JSON-schema definition sent to Azure OpenAI as a tool.
  * `impl` — a Python callable that receives parsed arguments and the live
            `AgentState`, and returns a JSON-serialisable result that we hand
            back to the model.

Keeping schemas and implementations co-located makes additions auditable.
"""
from __future__ import annotations

import os
import subprocess
import tempfile
from pathlib import Path
from typing import Any, Callable

from agent.state import AgentState
from tools.repo_scanner import RepoScanner
from tools.dependency_resolver import DependencyResolver
from tools.tf_module_registry import TerraformModuleRegistry
from tools.terraform_planner import TerraformPlanner, render_hcl
from tools.policy_engine import PolicyEngine


# Singletons — these objects are stateless and cheap to share.
_SCANNER = RepoScanner()
_RESOLVER = DependencyResolver()
_REGISTRY = TerraformModuleRegistry()
_PLANNER = TerraformPlanner()
_POLICY = PolicyEngine()


# --------------------------- tool implementations --------------------------


def _scan_repo(args: dict[str, Any], state: AgentState) -> dict[str, Any]:
    """Clone the repo to a temp dir (read-only) and scan."""
    repo_url = args["repo_url"]
    branch = args.get("branch", "main")
    if not _looks_like_safe_url(repo_url):
        return {"error": f"Refusing to clone unrecognised URL: {repo_url}"}
    with tempfile.TemporaryDirectory(prefix="bia-clone-") as tmp:
        # --depth 1 keeps the clone small; --filter=blob:none would be even
        # cheaper but is not universally supported by ADO Repos.
        proc = subprocess.run(
            ["git", "clone", "--depth", "1", "--branch", branch, repo_url, tmp],
            capture_output=True, timeout=120,
        )
        if proc.returncode != 0:
            return {"error": f"git clone failed: {proc.stderr.decode(errors='replace')}"}
        stacks = _SCANNER.scan(tmp)
    state["detected_stacks"] = stacks
    return {"detected_stacks": stacks, "count": len(stacks)}


def _resolve_dependencies(args: dict[str, Any], state: AgentState) -> dict[str, Any]:
    stacks = state.get("detected_stacks") or args.get("stacks") or []
    reqs, gpu, sku = _RESOLVER.resolve(stacks)
    state["runtime_requirements"] = reqs
    state["needs_gpu"] = gpu
    state["recommended_vm_sku"] = sku
    return {
        "runtime_requirements": reqs,
        "needs_gpu": gpu,
        "recommended_vm_sku": sku,
    }


def _list_modules(args: dict[str, Any], state: AgentState) -> dict[str, Any]:
    return {"modules": _REGISTRY.list_modules()}


def _propose_topology(args: dict[str, Any], state: AgentState) -> dict[str, Any]:
    selections = _REGISTRY.compose_default_topology(
        team_name=state["team_name"],
        business_unit=state["business_unit"],
        environment=state["target_environment"],
        recommended_sku=state.get("recommended_vm_sku") or args.get("sku"),
        needs_gpu=state.get("needs_gpu", False),
        requirements=state.get("runtime_requirements", []),
    )
    state["selected_modules"] = selections
    return {"selected_modules": selections}


def _render_and_plan(args: dict[str, Any], state: AgentState) -> dict[str, Any]:
    tags = _build_tags(state)
    hcl = render_hcl(state["selected_modules"], tags)
    summary = _PLANNER.plan(hcl)
    state["terraform_hcl"] = hcl
    state["terraform_plan_summary"] = summary
    return {
        "hcl_preview": hcl[:1500] + ("..." if len(hcl) > 1500 else ""),
        "plan_summary": summary[:4000],
    }


def _check_policy(args: dict[str, Any], state: AgentState) -> dict[str, Any]:
    tags = _build_tags(state)
    violations = _POLICY.evaluate(
        selections=state["selected_modules"],
        rendered_hcl=state.get("terraform_hcl", ""),
        environment=state["target_environment"],
        tags=tags,
    )
    state["policy_violations"] = violations
    state["policy_passed"] = not _POLICY.is_blocking(violations)
    return {"violations": violations, "passed": state["policy_passed"]}


def _emit_summary(args: dict[str, Any], state: AgentState) -> dict[str, Any]:
    state["final_summary"] = args["summary"]
    state["approval_status"] = (
        "auto-approved" if state.get("policy_passed")
        and state["target_environment"] != "prod" else "pending"
    )
    return {"approval_status": state["approval_status"]}


# --------------------------- tool specifications ---------------------------


TOOLS: list[dict[str, Any]] = [
    {
        "type": "function",
        "function": {
            "name": "scan_repo",
            "description": "Clone (depth=1) and scan a repo's manifest files. "
                           "Returns detected language stacks.",
            "parameters": {
                "type": "object",
                "properties": {
                    "repo_url": {"type": "string"},
                    "branch": {"type": "string", "default": "main"},
                },
                "required": ["repo_url"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "resolve_dependencies",
            "description": "Map detected stacks to required SDKs, apt packages, "
                           "GPU drivers, and a recommended Azure VM SKU.",
            "parameters": {"type": "object", "properties": {}},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "list_modules",
            "description": "Return the catalogue of approved Terraform modules.",
            "parameters": {"type": "object", "properties": {}},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "propose_topology",
            "description": "Produce a baseline ModuleSelection list using the "
                           "approved modules. Always includes managed_identity, "
                           "key_vault, log_analytics, nsg, vnet and a VMSS.",
            "parameters": {"type": "object", "properties": {}},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "render_and_plan",
            "description": "Render the root-module HCL and run `terraform plan`. "
                           "Returns a truncated preview and plan summary.",
            "parameters": {"type": "object", "properties": {}},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "check_policy",
            "description": "Evaluate the current selections + HCL against the "
                           "organisational policy. Returns violations.",
            "parameters": {"type": "object", "properties": {}},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "emit_summary",
            "description": "Finalise: hand the requestor a plain-English summary "
                           "and set approval status.",
            "parameters": {
                "type": "object",
                "properties": {
                    "summary": {"type": "string",
                                "description": "Markdown summary for the user."},
                },
                "required": ["summary"],
            },
        },
    },
]


IMPLEMENTATIONS: dict[str, Callable[[dict[str, Any], AgentState], dict[str, Any]]] = {
    "scan_repo": _scan_repo,
    "resolve_dependencies": _resolve_dependencies,
    "list_modules": _list_modules,
    "propose_topology": _propose_topology,
    "render_and_plan": _render_and_plan,
    "check_policy": _check_policy,
    "emit_summary": _emit_summary,
}


# ------------------------------ helpers ------------------------------------


def _looks_like_safe_url(url: str) -> bool:
    # Allow only HTTPS to Azure DevOps and GitHub Enterprise hosts.
    allowed_hosts = ("dev.azure.com", "visualstudio.com",
                     os.environ.get("ALLOWED_GIT_HOST", ""))
    return url.startswith("https://") and any(h and h in url for h in allowed_hosts)


def _build_tags(state: AgentState) -> dict[str, str]:
    return {
        "business_unit": state.get("business_unit", ""),
        "cost_center": state.get("business_unit", "unknown"),    # placeholder
        "environment": state.get("target_environment", "dev"),
        "data_classification": "internal",
        "owner_email": state.get("requestor_email", ""),
        "managed_by": "build-infra-agent",
    }
