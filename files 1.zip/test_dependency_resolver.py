"""Tests for tools/dependency_resolver.py."""
from __future__ import annotations

from agent.state import DetectedStack
from tools.dependency_resolver import DependencyResolver


def _stack(**kw) -> DetectedStack:
    base: DetectedStack = {
        "language": "python", "framework": None, "runtime_version": None,
        "package_manager": "pip", "manifest_path": "requirements.txt",
        "requires_gpu": False, "extras": {},
    }
    base.update(kw)
    return base


def test_dotnet8_picks_correct_sdk() -> None:
    reqs, gpu, sku = DependencyResolver().resolve(
        [_stack(language="dotnet", runtime_version="8.0")])
    sdk = next(r for r in reqs if r["kind"] == "sdk")
    assert sdk["name"] == "dotnet-sdk-8.0"
    assert gpu is False
    assert sku == "Standard_D4s_v5"


def test_gpu_workload_picks_gpu_sku_and_driver() -> None:
    reqs, gpu, sku = DependencyResolver().resolve([
        _stack(language="python", requires_gpu=True, runtime_version="3.11"),
    ])
    assert gpu is True
    assert sku.startswith("Standard_NC")
    assert any(r["kind"] == "gpu_driver" for r in reqs)
    assert any(r["name"] == "nvidia-container-toolkit" for r in reqs)


def test_heavy_framework_bumps_sku() -> None:
    _, _, sku = DependencyResolver().resolve([
        _stack(language="java", framework="spring-boot", runtime_version="21"),
    ])
    assert sku == "Standard_D8s_v5"


def test_unknown_version_falls_back() -> None:
    reqs, _, _ = DependencyResolver().resolve([
        _stack(language="node", runtime_version=None),
    ])
    sdk_names = [r["name"] for r in reqs if r["kind"] == "sdk"]
    assert "nodejs" in sdk_names


def test_ado_agent_always_added() -> None:
    reqs, _, _ = DependencyResolver().resolve([_stack(language="dotnet",
                                                       runtime_version="8.0")])
    assert any(r["name"] == "azure-pipelines-agent" for r in reqs)
