# Build Infra Agent

An AI-driven platform engineering agent that automates the provisioning of self-hosted
Azure DevOps build agents (VMs / VMSS) for heterogeneous tech stacks (.NET, Java,
Node.js, Python/ML, Go, etc.).

## Architecture

```
                ┌──────────────────────┐
   Teams chat → │   Bot Framework      │ ─┐
                └──────────────────────┘  │
                                          ▼
ADO pipeline → ┌──────────────────────┐ ┌──────────────────────────┐
   extension   │  FastAPI front-door  │→│  LangGraph orchestrator  │
               └──────────────────────┘ │  (Azure OpenAI GPT-4o)   │
                                        └──────────┬───────────────┘
                                                   │ tool-calls
                  ┌──────────────┬─────────────────┼──────────────────┬─────────────┐
                  ▼              ▼                 ▼                  ▼             ▼
            repo_scanner   dep_resolver     tf_module_registry   policy_engine   tf_planner
            (manifests)    (frameworks →    (pre-approved        (OPA-style      (terraform
                            runtimes/pkgs)   building blocks)     rules)          plan/apply)
```

## Components

| Path | Purpose |
|------|---------|
| `agent/state.py` | Shared `AgentState` TypedDict passed between LangGraph nodes |
| `agent/graph.py` | LangGraph state machine (scan → resolve → plan → policy → emit) |
| `agent/llm.py` | Azure OpenAI client wrapper with tool-calling |
| `tools/repo_scanner.py` | Parses csproj / pom.xml / package.json / requirements.txt / Dockerfile / go.mod |
| `tools/dependency_resolver.py` | Maps detected frameworks → required SDKs / apt packages / GPU need |
| `tools/tf_module_registry.py` | In-memory catalogue of approved Terraform building blocks |
| `tools/policy_engine.py` | Enforces private endpoints, CMK, approved SKUs, tag schema |
| `tools/terraform_planner.py` | Renders root module HCL, runs `terraform plan`, returns diff |
| `terraform_modules/` | The actual reusable, security-hardened Terraform modules |
| `azure_devops/extension.py` | ADO pipeline task entrypoint (`build_infra_agent_task`) |
| `teams_bot/bot.py` | Bot Framework adapter exposing the same graph over Teams |
| `policies/standards.yaml` | Declarative org standards consumed by `policy_engine` |
| `tests/` | Unit + integration tests with mocked Azure OpenAI |

## Run locally

```bash
pip install -r requirements.txt
export AZURE_OPENAI_ENDPOINT=https://<your-aoai>.openai.azure.com
export AZURE_OPENAI_API_KEY=<key>
export AZURE_OPENAI_DEPLOYMENT=gpt-4o
uvicorn agent.server:app --reload
```
