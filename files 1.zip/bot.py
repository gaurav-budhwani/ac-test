"""
Teams chat interface.

Uses the Bot Builder SDK adapter. The bot accepts a one-line onboarding
request, e.g.:

    onboard team=payments bu=fin env=dev repo=https://dev.azure.com/contoso/_git/payments

and replies with an adaptive card summarising the plan.

Run with:
    uvicorn teams_bot.bot:app --port 3978
"""
from __future__ import annotations

import json
import re
import shlex
from typing import Any

import httpx
from botbuilder.core import (
    BotFrameworkAdapter,
    BotFrameworkAdapterSettings,
    TurnContext,
)
from botbuilder.schema import Activity
from fastapi import FastAPI, Request, Response
import os


_ADAPTER = BotFrameworkAdapter(BotFrameworkAdapterSettings(
    app_id=os.environ.get("MICROSOFT_APP_ID", ""),
    app_password=os.environ.get("MICROSOFT_APP_PASSWORD", ""),
))
_AGENT_URL = os.environ.get("BUILD_INFRA_AGENT_URL", "http://localhost:8000")

app = FastAPI()


# --------------------------- parsing ---------------------------------------


_KV = re.compile(r"(\w+)=(\S+)")


def _parse(text: str) -> dict[str, str]:
    """Parse `key=value` pairs (quoted values supported via shlex)."""
    tokens = shlex.split(text)
    pairs: dict[str, str] = {}
    for tok in tokens:
        m = _KV.match(tok)
        if m:
            pairs[m.group(1).lower()] = m.group(2)
    return pairs


# --------------------------- adaptive card ---------------------------------


def _adaptive_card(payload: dict[str, Any]) -> dict[str, Any]:
    violations = payload.get("violations") or []
    violations_text = (
        "✅ No policy violations"
        if not violations
        else "❌ " + "; ".join(f"{v['rule_id']}: {v['message']}" for v in violations)
    )
    return {
        "type": "AdaptiveCard",
        "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
        "version": "1.5",
        "body": [
            {"type": "TextBlock", "size": "Large", "weight": "Bolder",
             "text": f"Build agent plan: {payload['team_name']}"},
            {"type": "FactSet", "facts": [
                {"title": "Approval", "value": payload["approval_status"]},
                {"title": "VM SKU",   "value": payload["recommended_vm_sku"]},
                {"title": "GPU?",     "value": str(payload["needs_gpu"])},
                {"title": "Policy",   "value": "passed"
                                              if payload["policy_passed"]
                                              else "FAILED"},
            ]},
            {"type": "TextBlock", "wrap": True, "text": violations_text},
            {"type": "TextBlock", "wrap": True,
             "text": payload.get("summary", "")[:2000]},
        ],
    }


# --------------------------- bot logic -------------------------------------


async def _on_turn(turn: TurnContext) -> None:
    if turn.activity.type != "message":
        return
    text = (turn.activity.text or "").strip()
    if text.lower().startswith("onboard"):
        kv = _parse(text[len("onboard"):])
        missing = [k for k in ("team", "bu", "repo") if k not in kv]
        if missing:
            await turn.send_activity(
                f"Missing required keys: {missing}. "
                f"Usage: `onboard team=<name> bu=<unit> env=<dev|test|prod> "
                f"repo=<https-url>`")
            return
        payload = {
            "team_name": kv["team"],
            "business_unit": kv["bu"],
            "target_environment": kv.get("env", "dev"),
            "repo_url": kv["repo"],
            "repo_branch": kv.get("branch", "main"),
            "requestor_email": (turn.activity.from_property and
                                turn.activity.from_property.aad_object_id) or "teams-user",
        }
        await turn.send_activity("⏳ Planning your build infra — give me a minute…")
        async with httpx.AsyncClient(timeout=600) as cx:
            r = await cx.post(f"{_AGENT_URL}/v1/onboard", json=payload)
        if r.status_code != 200:
            await turn.send_activity(f"Agent error: {r.status_code} {r.text[:500]}")
            return
        card = _adaptive_card(r.json())
        reply = Activity(
            type="message",
            attachments=[{
                "contentType": "application/vnd.microsoft.card.adaptive",
                "content": card,
            }],
        )
        await turn.send_activity(reply)
    else:
        await turn.send_activity(
            "Hi! I'm the Build Infra Agent. Try:\n"
            "`onboard team=payments bu=fin env=dev "
            "repo=https://dev.azure.com/contoso/_git/payments`")


# --------------------------- HTTP plumbing ---------------------------------


@app.post("/api/messages")
async def messages(req: Request) -> Response:
    body = await req.json()
    activity = Activity().deserialize(body)
    auth_header = req.headers.get("authorization", "")
    await _ADAPTER.process_activity(activity, auth_header, _on_turn)
    return Response(status_code=200)
