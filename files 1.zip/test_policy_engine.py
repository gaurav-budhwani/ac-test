"""Tests for tools/policy_engine.py."""
from __future__ import annotations

from agent.state import ModuleSelection
from tools.policy_engine import PolicyEngine


def _good_selections() -> list[ModuleSelection]:
    return [
        ModuleSelection(module_name="vnet", source="x", version="1", inputs={}),
        ModuleSelection(module_name="nsg", source="x", version="1", inputs={}),
        ModuleSelection(module_name="managed_identity", source="x",
                        version="1", inputs={}),
        ModuleSelection(module_name="key_vault", source="x", version="1",
                        inputs={"purge_protection_enabled": True}),
        ModuleSelection(module_name="log_analytics", source="x",
                        version="1", inputs={}),
        ModuleSelection(module_name="vmss_linux", source="x", version="1",
                        inputs={"sku": "Standard_D4s_v5", "instance_count": 2}),
    ]


def _tags() -> dict[str, str]:
    return {
        "business_unit": "fin", "cost_center": "1234",
        "environment": "prod", "data_classification": "internal",
        "owner_email": "dev@contoso",
    }


def test_clean_plan_passes() -> None:
    engine = PolicyEngine()
    violations = engine.evaluate(_good_selections(), "module \"x\" {}",
                                 environment="prod", tags=_tags())
    assert violations == []
    assert engine.is_blocking(violations) is False


def test_missing_mandatory_module_blocks() -> None:
    sels = [s for s in _good_selections() if s["module_name"] != "key_vault"]
    violations = PolicyEngine().evaluate(sels, "", "prod", _tags())
    assert any(v["rule_id"] == "POL-001" for v in violations)


def test_bad_sku_blocks() -> None:
    sels = _good_selections()
    sels[-1] = ModuleSelection(module_name="vmss_linux", source="x", version="1",
                                inputs={"sku": "Standard_A1_v2", "instance_count": 2})
    violations = PolicyEngine().evaluate(sels, "", "prod", _tags())
    assert any(v["rule_id"] == "POL-002" for v in violations)


def test_missing_tag_blocks() -> None:
    tags = _tags()
    del tags["cost_center"]
    violations = PolicyEngine().evaluate(_good_selections(), "", "prod", tags)
    assert any(v["rule_id"] == "POL-003" for v in violations)


def test_forbidden_pattern_blocks() -> None:
    hcl = 'resource "azurerm_public_ip_address" "x" {}'
    violations = PolicyEngine().evaluate(_good_selections(), hcl, "prod", _tags())
    assert any(v["rule_id"] == "POL-004" for v in violations)


def test_prod_requires_purge_protection() -> None:
    sels = _good_selections()
    # disable purge protection
    for s in sels:
        if s["module_name"] == "key_vault":
            s["inputs"]["purge_protection_enabled"] = False
    violations = PolicyEngine().evaluate(sels, "", "prod", _tags())
    assert any(v["rule_id"] == "POL-006" for v in violations)


def test_prod_min_instances_enforced() -> None:
    sels = _good_selections()
    for s in sels:
        if s["module_name"] == "vmss_linux":
            s["inputs"]["instance_count"] = 1
    violations = PolicyEngine().evaluate(sels, "", "prod", _tags())
    assert any(v["rule_id"] == "POL-005" for v in violations)
