"""
Azure DevOps pipeline-task entrypoint.

Packaged as an ADO extension (vss-extension.json + task.json — not included
here because they are static manifests, but they would point at this file as
the execution target via the `Node` or `Python` handler).

Inputs from `$ENV`:
    INPUT_TEAMNAME
    INPUT_BUSINESSUNIT
    INPUT_TARGETENVIRONMENT
    INPUT_REPOURL       (defaults to $BUILD_REPOSITORY_URI)
    INPUT_REPOBRANCH    (defaults to $BUILD_SOURCEBRANCHNAME)
    SYSTEM_TEAMFOUNDATIONCOLLECTIONURI, etc. (provided by ADO)

Outputs (written via ADO logging commands):
    BuildInfraAgent.ApprovalStatus
    BuildInfraAgent.PolicyPassed
    BuildInfraAgent.RecommendedSku
"""
from __future__ import annotations

import json
import os
import sys
from urllib import request as urlrequest


def _log(msg: str) -> None:
    print(msg, flush=True)


def _set_output(name: str, value: str) -> None:
    # ADO logging command — picked up by the agent and exported as a variable.
    print(f"##vso[task.setvariable variable=BuildInfraAgent.{name};isOutput=true]{value}",
          flush=True)


def _input(name: str, fallback_env: str | None = None, default: str = "") -> str:
    val = os.environ.get(f"INPUT_{name.upper()}")
    if not val and fallback_env:
        val = os.environ.get(fallback_env)
    return val or default


def main() -> int:
    endpoint = os.environ.get("BUILD_INFRA_AGENT_URL")
    if not endpoint:
        _log("##vso[task.logissue type=error]BUILD_INFRA_AGENT_URL is not set")
        return 1

    payload = {
        "team_name": _input("teamName"),
        "business_unit": _input("businessUnit"),
        "target_environment": _input("targetEnvironment", default="dev"),
        "repo_url": _input("repoUrl", fallback_env="BUILD_REPOSITORY_URI"),
        "repo_branch": _input("repoBranch",
                              fallback_env="BUILD_SOURCEBRANCHNAME", default="main"),
        "requestor_email": os.environ.get("BUILD_REQUESTEDFOREMAIL", "unknown@contoso"),
    }
    _log(f"[build-infra-agent] payload: {json.dumps(payload)}")

    body = json.dumps(payload).encode()
    req = urlrequest.Request(
        f"{endpoint.rstrip('/')}/v1/onboard",
        data=body,
        method="POST",
        headers={
            "Content-Type": "application/json",
            # ADO injects this — agent verifies caller is the ADO service.
            "Authorization": f"Bearer {os.environ.get('SYSTEM_ACCESSTOKEN','')}",
        },
    )
    try:
        with urlrequest.urlopen(req, timeout=600) as resp:
            data = json.loads(resp.read().decode())
    except Exception as exc:                                        # noqa: BLE001
        _log(f"##vso[task.logissue type=error]agent call failed: {exc}")
        return 2

    _log("[build-infra-agent] response:")
    _log(data.get("summary", "(no summary)"))
    _set_output("ApprovalStatus", data["approval_status"])
    _set_output("PolicyPassed", str(data["policy_passed"]).lower())
    _set_output("RecommendedSku", data.get("recommended_vm_sku", ""))

    if not data["policy_passed"]:
        # Pipeline visible warning so reviewers see violations on the run page.
        for v in data.get("violations", []):
            _log(f"##vso[task.logissue type=warning]"
                 f"{v['rule_id']}: {v['message']}")
        if data["approval_status"] == "rejected":
            return 3
    return 0


if __name__ == "__main__":
    sys.exit(main())
