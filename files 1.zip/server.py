"""
FastAPI front door.

Exposes:
    POST /v1/onboard      Synchronous run of the full LangGraph workflow.
    GET  /healthz         Liveness probe.

Both the ADO pipeline extension and the Teams bot call this same endpoint,
so the workflow is defined once.
"""
from __future__ import annotations

import logging
from typing import Literal

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field, HttpUrl

from agent.graph import build_graph
from agent.state import AgentState

log = logging.getLogger("build_infra_agent")
logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s %(levelname)s %(name)s %(message)s")

app = FastAPI(title="Build Infra Agent", version="1.0.0")
_graph = None       # lazy so test imports don't require AOAI env vars


class OnboardRequest(BaseModel):
    team_name: str = Field(min_length=2, max_length=40)
    repo_url: HttpUrl
    repo_branch: str = "main"
    business_unit: str = Field(min_length=2, max_length=30)
    target_environment: Literal["dev", "test", "prod"] = "dev"
    requestor_email: str


class OnboardResponse(BaseModel):
    team_name: str
    approval_status: str
    policy_passed: bool
    needs_gpu: bool
    recommended_vm_sku: str
    summary: str
    plan_summary: str
    hcl: str
    violations: list[dict]


def _get_graph():
    global _graph
    if _graph is None:
        _graph = build_graph()
    return _graph


@app.get("/healthz")
def healthz() -> dict[str, str]:
    return {"status": "ok"}


@app.post("/v1/onboard", response_model=OnboardResponse)
def onboard(req: OnboardRequest) -> OnboardResponse:
    log.info("onboard request from %s for team %s", req.requestor_email, req.team_name)
    initial: AgentState = {
        "team_name": req.team_name,
        "repo_url": str(req.repo_url),
        "repo_branch": req.repo_branch,
        "business_unit": req.business_unit,
        "target_environment": req.target_environment,
        "requestor_email": req.requestor_email,
        "iteration": 0,
        "messages": [],
    }
    try:
        final = _get_graph().invoke(initial)
    except Exception as exc:                                        # noqa: BLE001
        log.exception("graph invocation failed")
        raise HTTPException(500, f"agent failed: {exc}") from exc

    return OnboardResponse(
        team_name=req.team_name,
        approval_status=final.get("approval_status", "pending"),
        policy_passed=final.get("policy_passed", False),
        needs_gpu=final.get("needs_gpu", False),
        recommended_vm_sku=final.get("recommended_vm_sku", ""),
        summary=final.get("final_summary", ""),
        plan_summary=final.get("terraform_plan_summary", ""),
        hcl=final.get("terraform_hcl", ""),
        violations=final.get("policy_violations", []),
    )
